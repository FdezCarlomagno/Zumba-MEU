"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { Button } from "@/components/ui/button"
import { CountdownTimer } from "@/components/countdown-timer"
import { VideoBackground } from "@/components/video-background"
import { Instagram, Calendar, Sparkles, ArrowRight } from "lucide-react"
import type { Event } from "@/lib/types"

gsap.registerPlugin(ScrollTrigger)

interface HeroSectionProps {
  currentEvent: Event | null
  nextEvent: Event | null
}

export function HeroSection({ currentEvent, nextEvent }: HeroSectionProps) {
  const heroRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const backgroundRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!heroRef.current || !contentRef.current || !backgroundRef.current) return

    const tl = gsap.timeline({ defaults: { ease: "power4.out" } })

    tl.from(contentRef.current.children, {
      y: 120,
      opacity: 0,
      duration: 1.2,
      stagger: 0.2,
      scale: 0.8,
      rotation: -5,
    })

    gsap.to(backgroundRef.current, {
      scrollTrigger: {
        trigger: heroRef.current,
        start: "top top",
        end: "bottom top",
        scrub: 1,
      },
      scale: 1.3,
      opacity: 1,
    })

    gsap.to(contentRef.current, {
      scrollTrigger: {
        trigger: heroRef.current,
        start: "top top",
        end: "bottom top",
        scrub: 1,
      },
      y: 200,
      opacity: 1,
      scale: 0.7,
    })

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [])

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToServices = () => {
    document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })
  }

  // Case A: Upcoming event
  if (nextEvent && nextEvent.status === "upcoming") {
    return (
      <section
        id="home"
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <div
          ref={backgroundRef}
          className="absolute inset-0 bg-gradient-to-br from-pink-500 via-purple-600 to-yellow-500 animate-gradient"
        />
        <VideoBackground intensity={0.6} />

        <div ref={contentRef} className="relative z-10 container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl sm:text-6xl md:text-8xl lg:text-9xl font-display font-bold mb-8 text-balance drop-shadow-2xl leading-tight">
            Next Zumba Party Starts In...
          </h1>

          <div className="mb-12 flex justify-center">
            <CountdownTimer targetDate={nextEvent.date} />
          </div>

          <p className="text-xl sm:text-3xl md:text-5xl mb-12 text-balance font-display drop-shadow-lg">
            {nextEvent.name}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={scrollToContact}
              className="w-full sm:w-auto bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-900 hover:from-yellow-500 hover:to-yellow-600 font-bold text-lg sm:text-xl px-8 sm:px-10 py-6 sm:py-7 rounded-full shadow-2xl hover:scale-110 transition-all duration-300 border-4 border-white"
            >
              <Calendar className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
              Book Now
              <ArrowRight className="ml-2 h-5 w-5 sm:h-6 sm:w-6" />
            </Button>
            <Button
              size="lg"
              onClick={scrollToServices}
              className="w-full sm:w-auto glass-strong text-white hover:glass-strong hover:scale-105 transition-all duration-300 text-base sm:text-lg px-6 sm:px-8 py-5 sm:py-6 rounded-full border-2 border-white/40 shadow-xl"
            >
              <Sparkles className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
              Party Details
            </Button>
          </div>
        </div>
      </section>
    )
  }

  // Case B: Event is live
  if (currentEvent) {
    return (
      <section
        id="home"
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <div
          ref={backgroundRef}
          className="absolute inset-0 bg-gradient-to-br from-purple-600 via-pink-500 to-yellow-400 animate-pulse"
        />
        <VideoBackground intensity={0.7} />

        <div ref={contentRef} className="relative z-10 container mx-auto px-4 text-center text-white">
          <h1 className="text-5xl sm:text-7xl md:text-9xl lg:text-[10rem] font-display font-bold mb-8 text-balance drop-shadow-2xl leading-tight">
            See you at the party!
          </h1>

          <p className="text-2xl sm:text-4xl md:text-6xl mb-12 text-balance font-display flex items-center justify-center gap-4 drop-shadow-lg">
            <Sparkles className="h-8 w-8 sm:h-12 sm:w-12 animate-spin" />
            We're dancing right now
            <Sparkles className="h-8 w-8 sm:h-12 sm:w-12 animate-spin" />
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={() => window.open("https://instagram.com", "_blank")}
              className="w-full sm:w-auto bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:from-pink-600 hover:to-purple-700 font-bold text-lg sm:text-xl px-8 sm:px-10 py-6 sm:py-7 rounded-full shadow-2xl hover:scale-110 transition-all duration-300 border-4 border-white"
            >
              <Instagram className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
              Follow on Instagram
              <ArrowRight className="ml-2 h-5 w-5 sm:h-6 sm:w-6" />
            </Button>
            <Button
              size="lg"
              onClick={scrollToServices}
              className="w-full sm:w-auto glass-strong text-white hover:scale-105 transition-all duration-300 text-base sm:text-lg px-6 sm:px-8 py-5 sm:py-6 rounded-full border-2 border-white/40 shadow-xl"
            >
              <Calendar className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
              See Next Events
            </Button>
          </div>
        </div>
      </section>
    )
  }

  // Case C: Event finished, show next event
  if (nextEvent && nextEvent.status === "finished") {
    return (
      <section
        id="home"
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-accent to-secondary" />
        <VideoBackground intensity={0.3} />

        <div ref={contentRef} className="relative z-10 container mx-auto px-4 text-center text-white">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold mb-8 text-balance drop-shadow-2xl">
            That was epic.
          </h1>

          <p className="text-2xl md:text-4xl mb-8 text-balance font-display drop-shadow-lg">Next party in...</p>

          <div className="mb-12 flex justify-center">
            <CountdownTimer targetDate={nextEvent.date} />
          </div>

          <Button
            size="lg"
            onClick={scrollToContact}
            className="glass-strong text-white hover:scale-105 transition-all text-lg px-8 py-6 rounded-full border-2 border-white/40 shadow-2xl"
          >
            <Calendar className="mr-2 h-5 w-5" />
            Book Now
          </Button>
        </div>
      </section>
    )
  }

  // Case D: No events scheduled
  return (
    <section id="home" ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div
        ref={backgroundRef}
        className="absolute inset-0 bg-gradient-to-br from-pink-500 via-purple-600 to-yellow-400"
      />
      <VideoBackground intensity={0.6} />

      <div ref={contentRef} className="relative z-10 container mx-auto px-4 text-center text-white">
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-[8rem] font-display font-bold mb-12 text-balance leading-none drop-shadow-2xl">
          Dance.
          <br />
          Play.
          <br />
          Celebrate.
        </h1>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            size="lg"
            onClick={scrollToContact}
            className="w-full sm:w-auto bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-900 hover:from-yellow-500 hover:to-yellow-600 font-bold text-lg sm:text-xl px-8 sm:px-10 py-6 sm:py-7 rounded-full shadow-2xl hover:scale-105 transition-all duration-300 border-4 border-white"
          >
            <Calendar className="mr-2 h-5 w-5 sm:h-6 sm:w-6" />
            Book a Party
            <ArrowRight className="ml-2 h-5 w-5 sm:h-6 sm:w-6" />
          </Button>
          <Button
            size="lg"
            onClick={scrollToServices}
            className="w-full sm:w-auto glass-strong text-white hover:scale-105 transition-all duration-300 text-base sm:text-lg px-6 sm:px-8 py-5 sm:py-6 rounded-full border-2 border-white/40 shadow-xl"
          >
            <Sparkles className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
            See Services
          </Button>
        </div>
      </div>
    </section>
  )
}
