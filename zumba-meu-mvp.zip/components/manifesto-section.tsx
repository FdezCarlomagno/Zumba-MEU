"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export function ManifestoSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const wordsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current || !wordsRef.current) return

    const words = wordsRef.current.children

    gsap.from(words, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top center",
        end: "bottom center",
        scrub: 1,
      },
      opacity: 0,
      y: 100,
      stagger: 0.3,
    })

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [])

  return (
    <section
      ref={sectionRef}
      className="min-h-screen flex items-center justify-center bg-background py-20 overflow-hidden"
    >
      <div ref={wordsRef} className="container mx-auto px-4 text-center">
        <h2 className="text-6xl md:text-8xl lg:text-9xl font-display font-bold text-foreground mb-6">Dance.</h2>
        <h2 className="text-6xl md:text-8xl lg:text-9xl font-display font-bold text-primary mb-6">Play.</h2>
        <h2 className="text-6xl md:text-8xl lg:text-9xl font-display font-bold text-accent mb-6">Celebrate.</h2>
      </div>
    </section>
  )
}
