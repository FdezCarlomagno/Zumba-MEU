"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Sparkles, Menu, X } from "lucide-react"

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsMobileMenuOpen(false)
    }
  }

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "glass-strong shadow-lg" : "transparent",
      )}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl md:text-4xl font-display font-bold text-white flex items-center gap-2 drop-shadow-lg hover:scale-105 transition-transform"
          >
            <Sparkles className="h-4 w-4 md:h-4 md:w-4 text-yellow-300 animate-pulse" />
            <span className="text-shadow-lg">Zumba MEU</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection("home")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors drop-shadow-md text-lg"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("services")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors drop-shadow-md text-lg"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors drop-shadow-md text-lg"
            >
              Contact
            </button>
          </div>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-white p-2 hover:bg-white/20 rounded-lg transition-all"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        <div
          className={cn(
            "md:hidden overflow-hidden transition-all duration-500 ease-in-out",
            isMobileMenuOpen ? "max-h-64 opacity-100 mt-4" : "max-h-0 opacity-0",
          )}
        >
          <div className="flex flex-col gap-4 py-4 glass-strong rounded-xl">
            <button
              onClick={() => scrollToSection("home")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors text-lg py-2"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("services")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors text-lg py-2"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-white font-semibold hover:text-yellow-300 transition-colors text-lg py-2"
            >
              Contact
            </button>
          </div>
        </div>
      </div>
    </nav>
  )
}
