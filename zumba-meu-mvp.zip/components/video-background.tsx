"use client"

import { useEffect, useRef, useState } from "react"

interface VideoBackgroundProps {
  intensity?: number
}

export function VideoBackground({ intensity = 0.5 }: VideoBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const mousePosition = useRef({ x: 0, y: 0 })
  const targetPosition = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const canvas = canvasRef.current
    const video = videoRef.current
    if (!canvas || !video) return

    const ctx = canvas.getContext("2d", { willReadFrequently: false })
    if (!ctx) return

    let animationFrameId: number

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      targetPosition.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      }
    }

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    const animate = () => {
      if (!video.paused && !video.ended && video.readyState >= 2) {
        // Smooth mouse position interpolation
        mousePosition.current.x += (targetPosition.current.x - mousePosition.current.x) * 0.1
        mousePosition.current.y += (targetPosition.current.y - mousePosition.current.y) * 0.1

        ctx.save()

        // Clear and draw video
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const data = imageData.data
        const time = Date.now() * 0.001

        for (let y = 0; y < canvas.height; y += 2) {
          for (let x = 0; x < canvas.width; x += 2) {
            const dx = x - mousePosition.current.x
            const dy = y - mousePosition.current.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 200) {
              const force = (200 - distance) / 200
              const angle = Math.atan2(dy, dx)
              const wave = Math.sin(distance * 0.05 - time * 3) * force * intensity * 60

              const sourceX = Math.floor(x + Math.cos(angle) * wave)
              const sourceY = Math.floor(y + Math.sin(angle) * wave)

              if (sourceX >= 0 && sourceX < canvas.width && sourceY >= 0 && sourceY < canvas.height) {
                const targetIndex = (y * canvas.width + x) * 4
                const sourceIndex = (sourceY * canvas.width + sourceX) * 4

                data[targetIndex] = data[sourceIndex]
                data[targetIndex + 1] = data[sourceIndex + 1]
                data[targetIndex + 2] = data[sourceIndex + 2]
              }
            }
          }
        }

        ctx.putImageData(imageData, 0, 0)

        ctx.globalCompositeOperation = "lighter"
        const gradient = ctx.createRadialGradient(
          mousePosition.current.x,
          mousePosition.current.y,
          0,
          mousePosition.current.x,
          mousePosition.current.y,
          150,
        )
        gradient.addColorStop(0, "rgba(255, 100, 255, 0.3)")
        gradient.addColorStop(0.5, "rgba(100, 200, 255, 0.1)")
        gradient.addColorStop(1, "rgba(255, 255, 100, 0)")

        ctx.fillStyle = gradient
        ctx.fillRect(0, 0, canvas.width, canvas.height)

        ctx.restore()
      }

      animationFrameId = requestAnimationFrame(animate)
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)
    canvas.addEventListener("mousemove", handleMouseMove)

    video.addEventListener("loadeddata", () => {
      setIsLoaded(true)
      animate()
    })

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      canvas.removeEventListener("mousemove", handleMouseMove)
      cancelAnimationFrame(animationFrameId)
    }
  }, [intensity])

  return (
    <>
      <video ref={videoRef} autoPlay loop muted playsInline className="hidden" onLoadedData={() => setIsLoaded(true)}>
        <source src="https://cdn.pixabay.com/video/2023/05/06/161156-825120963_large.mp4" type="video/mp4" />
      </video>
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
          isLoaded ? "opacity-40" : "opacity-0"
        }`}
      />
    </>
  )
}
