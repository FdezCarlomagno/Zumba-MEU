"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useMobile } from "@/hooks/use-mobile"

gsap.registerPlugin(ScrollTrigger)

const experiences = [
  {
    title: "Zumba Kids",
    image: "/kids-zumba-dance-class-energy.jpg",
    description: "Fun fitness for children",
  },
  {
    title: "Kids Disco",
    image: "/kids-disco-party-lights-colorful.jpg",
    description: "Dance parties they love",
  },
  {
    title: "Zumba Party",
    image: "/zumba-party-celebration-adults-dancing.jpg",
    description: "Ultimate celebration experience",
  },
  {
    title: "Birthday Parties",
    image: "/kids-birthday-party-celebration-balloons.jpg",
    description: "Make memories that last",
  },
]

export function ExperienceGallery() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const isMobile = useMobile()

  useEffect(() => {
    if (!sectionRef.current || !containerRef.current || isMobile) return

    const container = containerRef.current
    const cards = container.children

    // Horizontal scroll animation
    const scrollWidth = container.scrollWidth - window.innerWidth

    gsap.to(container, {
      x: -scrollWidth,
      ease: "none",
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top top",
        end: () => `+=${scrollWidth}`,
        scrub: 1,
        pin: true,
      },
    })

    // Parallax effect on cards
    Array.from(cards).forEach((card, index) => {
      gsap.to(card, {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: () => `+=${scrollWidth}`,
          scrub: 1,
        },
        y: index % 2 === 0 ? -50 : 50,
      })
    })

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [isMobile])

  // Mobile: vertical scroll
  if (isMobile) {
    return (
      <section className="py-20 bg-muted overflow-hidden">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-6xl font-display font-bold text-center mb-12 text-foreground">
            Experience the Energy
          </h2>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div key={index} className="rounded-3xl overflow-hidden glass shadow-2xl">
                <div className="h-80 bg-cover bg-center" style={{ backgroundImage: `url(${exp.image})` }} />
                <div className="p-6">
                  <h3 className="text-2xl font-display font-bold mb-2 text-foreground">{exp.title}</h3>
                  <p className="text-muted-foreground text-lg">{exp.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  // Desktop: horizontal scroll
  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-accent/20 to-secondary/20"
      style={{ minHeight: "100vh" }}
    >
      <div className="absolute top-8 left-1/2 -translate-x-1/2 z-10">
        <p className="text-lg font-display font-bold text-foreground glass px-6 py-3 rounded-full animate-bounce">
          Scroll to explore →
        </p>
      </div>

      <div ref={containerRef} className="flex items-center h-screen gap-8 px-8 py-20">
        {experiences.map((exp, index) => (
          <div
            key={index}
            className="flex-shrink-0 w-[500px] h-[600px] rounded-3xl overflow-hidden glass shadow-2xl hover:scale-105 transition-transform"
          >
            <div className="h-[400px] bg-cover bg-center" style={{ backgroundImage: `url(${exp.image})` }} />
            <div className="p-8 h-[200px] flex flex-col justify-center">
              <h3 className="text-4xl font-display font-bold mb-3 text-foreground">{exp.title}</h3>
              <p className="text-xl text-muted-foreground">{exp.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
