"use client"

import { Heart, Instagram, Mail, Phone, Sparkles } from "lucide-react"

export function Footer() {
  return (
    <footer className="relative bg-gradient-to-br from-primary via-accent to-secondary text-white py-16 overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-white animate-pulse" />
        <div className="absolute bottom-10 right-10 w-40 h-40 rounded-full bg-white animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/3 w-24 h-24 rounded-full bg-white animate-pulse delay-500" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand section */}
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-4">
              <Sparkles className="h-8 w-8 text-yellow-300" />
              <h3 className="text-4xl font-display font-bold">Zumba MEU</h3>
            </div>
            <p className="text-white/90 text-lg leading-relaxed">
              Where every beat brings us together and every move creates magic!
            </p>
            <div className="mt-4 flex items-center justify-center md:justify-start gap-2 text-yellow-300">
              <Heart className="h-5 w-5 animate-pulse" />
              <span className="font-display font-bold">Made with love for families</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h4 className="text-2xl font-display font-bold mb-6 flex items-center justify-center gap-2">
              <Sparkles className="h-6 w-6 text-yellow-300" />
              Let's Connect
            </h4>
            <ul className="space-y-3">
              <li>
                <button
                  onClick={() => document.getElementById("home")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-white/90 hover:text-yellow-300 transition-colors text-lg font-semibold hover:scale-110 inline-block transition-transform"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-white/90 hover:text-yellow-300 transition-colors text-lg font-semibold hover:scale-110 inline-block transition-transform"
                >
                  Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                  className="text-white/90 hover:text-yellow-300 transition-colors text-lg font-semibold hover:scale-110 inline-block transition-transform"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-right">
            <h4 className="text-2xl font-display font-bold mb-6">Get in Touch</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center md:justify-end gap-2 text-white/90 hover:text-yellow-300 transition-colors group"
                >
                  <Instagram className="h-5 w-5 group-hover:scale-125 transition-transform" />
                  <span className="text-lg">@zumbameu</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@zumbameu.com"
                  className="flex items-center justify-center md:justify-end gap-2 text-white/90 hover:text-yellow-300 transition-colors group"
                >
                  <Mail className="h-5 w-5 group-hover:scale-125 transition-transform" />
                  <span className="text-lg">info@zumbameu.com</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+1234567890"
                  className="flex items-center justify-center md:justify-end gap-2 text-white/90 hover:text-yellow-300 transition-colors group"
                >
                  <Phone className="h-5 w-5 group-hover:scale-125 transition-transform" />
                  <span className="text-lg">+123 456 7890</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-white/20 pt-8 text-center">
          <p className="text-white/80 text-lg font-display">
            {new Date().getFullYear()} Zumba MEU - Dance, Play, Celebrate
          </p>
          <p className="text-white/60 mt-2 flex items-center justify-center gap-2">
            <Sparkles className="h-4 w-4" />
            Creating unforgettable moments, one dance at a time
            <Sparkles className="h-4 w-4" />
          </p>
        </div>
      </div>
    </footer>
  )
}
