"use client"

import { useCountdown } from "@/hooks/use-countdown"

interface CountdownTimerProps {
  targetDate: string
  size?: "sm" | "lg"
}

export function CountdownTimer({ targetDate, size = "lg" }: CountdownTimerProps) {
  const timeLeft = useCountdown(targetDate)

  const TimeUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div
        className={cn(
          "glass-strong rounded-3xl flex items-center justify-center font-display font-bold text-white shadow-2xl transform hover:scale-110 transition-transform",
          size === "lg" ? "w-20 h-20 md:w-32 md:h-32 text-3xl md:text-6xl" : "w-16 h-16 text-2xl",
        )}
      >
        {value.toString().padStart(2, "0")}
      </div>
      <span
        className={cn("mt-3 text-white font-bold drop-shadow-lg", size === "lg" ? "text-sm md:text-lg" : "text-xs")}
      >
        {label}
      </span>
    </div>
  )

  return (
    <div className="flex gap-4 md:gap-6">
      <TimeUnit value={timeLeft.days} label="Days" />
      <TimeUnit value={timeLeft.hours} label="Hours" />
      <TimeUnit value={timeLeft.minutes} label="Minutes" />
      <TimeUnit value={timeLeft.seconds} label="Seconds" />
    </div>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(" ")
}
