"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageCircle, Mail, ArrowRight } from "lucide-react"

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    eventType: "",
    date: "",
    message: "",
  })

  const handleWhatsApp = () => {
    const message = `Hi! I'm interested in booking:\n\nName: ${formData.name}\nEvent Type: ${formData.eventType}\nPreferred Date: ${formData.date}\nMessage: ${formData.message}`
    const encoded = encodeURIComponent(message)
    window.open(`https://wa.me/?text=${encoded}`, "_blank")
  }

  const handleEmail = () => {
    const subject = `Booking Request - ${formData.eventType}`
    const body = `Name: ${formData.name}\n\nEvent Type: ${formData.eventType}\n\nPreferred Date: ${formData.date}\n\nMessage: ${formData.message}`
    window.location.href = `mailto:info@zumbameu.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  return (
    <section id="contact" className="py-20 bg-muted overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-5xl md:text-7xl font-display font-bold text-center mb-4 text-foreground">
            {"Let's Get Started"}
          </h2>
          <p className="text-xl text-center text-muted-foreground mb-12">Book your next event or class with us today</p>

          <Card className="glass shadow-2xl">
            <CardHeader>
              <CardTitle className="text-3xl font-display">Booking Request</CardTitle>
              <CardDescription className="text-lg">
                Fill out the form below and we'll get back to you as soon as possible
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-base font-semibold">
                    Your Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="text-base py-6"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="event-type" className="text-base font-semibold">
                    Event Type
                  </Label>
                  <Select
                    value={formData.eventType}
                    onValueChange={(value) => setFormData({ ...formData, eventType: value })}
                  >
                    <SelectTrigger id="event-type" className="text-base py-6">
                      <SelectValue placeholder="Select an event type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="zumba-kids">Zumba Kids</SelectItem>
                      <SelectItem value="kids-disco">Kids Disco</SelectItem>
                      <SelectItem value="zumba-party">Zumba Party</SelectItem>
                      <SelectItem value="birthday-party">Birthday Disco Party</SelectItem>
                      <SelectItem value="equipment-hire">Equipment Hire</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date" className="text-base font-semibold">
                    Preferred Date
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="text-base py-6"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-base font-semibold">
                    Message
                  </Label>
                  <Textarea
                    id="message"
                    placeholder="Tell us more about your event..."
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button
                    onClick={handleWhatsApp}
                    className="flex-1 rounded-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold text-lg py-7 shadow-xl hover:scale-105 transition-all"
                    size="lg"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Send via WhatsApp
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                  <Button
                    onClick={handleEmail}
                    variant="outline"
                    className="flex-1 rounded-full glass-dark hover:scale-105 transition-all text-base py-6 bg-transparent"
                    size="lg"
                  >
                    <Mail className="mr-2 h-5 w-5" />
                    Send via Email
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
