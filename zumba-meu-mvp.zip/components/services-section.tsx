"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Music, PartyPopper, Sparkles, Cake, Mic, ArrowRight } from "lucide-react"

const services = [
  {
    title: "Zumba Kids",
    description: "High-energy dance classes designed specifically for children ages 4-12",
    icon: Music,
  },
  {
    title: "Kids Disco",
    description: "Fun disco parties with lights, music, and dancing for all ages",
    icon: PartyPopper,
  },
  {
    title: "Zumba Party",
    description: "Adult Zumba sessions perfect for celebrations and events",
    icon: Sparkles,
  },
  {
    title: "Birthday Disco Parties",
    description: "Complete party packages with music, lights, and entertainment",
    icon: Cake,
  },
  {
    title: "Equipment Hire",
    description: "Professional sound systems, lighting, and party equipment rental",
    icon: Mic,
  },
]

export function ServicesSection() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="services" className="py-20 bg-background overflow-hidden">
      <div className="container mx-auto px-4">
        <h2 className="text-5xl md:text-7xl font-display font-bold text-center mb-4 text-foreground">Our Services</h2>
        <p className="text-xl text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
          From fitness classes to unforgettable parties, we bring the energy and fun
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <Card
                key={index}
                className="glass border-2 border-primary/20 hover:border-primary hover:scale-105 transition-all shadow-xl"
              >
                <CardHeader>
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-2xl font-display font-bold">{service.title}</CardTitle>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col gap-3">
                    <Button
                      onClick={scrollToContact}
                      className="w-full rounded-full shadow-lg hover:scale-105 transition-transform bg-gradient-to-r from-primary to-accent text-white font-bold py-6 text-lg"
                      size="lg"
                    >
                      Book Now
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full rounded-full glass-dark hover:scale-105 transition-transform text-foreground"
                    >
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
