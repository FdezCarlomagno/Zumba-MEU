"use client"

import { useLenis } from "@/hooks/use-lenis"

export function SmoothScroll() {
  useLenis()
  return null
}
